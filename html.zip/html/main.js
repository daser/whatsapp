$(function() {

    //var socket = io();
     function removeTags(txt){
        var rex = /(<([^>]+)>)/ig;
        return txt.replace(rex, '');
    };

    var socket = io.connect('https://whatsappdemo.herokuapp.com');

 // socket.on('send', function(data) {
 //        var username = data.username;
 //        var message = data.message;
 //        var html = "<div class='msg'><div class='user'>" + username + "</div><div class='txt'>" + message + "</div></div>";
 //        $('.messages').append(html);
 //    });

 socket.on('message', function(data){
 		console.log(data.message);
 });


socket.on('fetchUsers', function(data){
		console.log("daser");
		console.log(data);
});

socket.on('createMsg', function(data){
	console.log(data);
});

 $('#send-message').click(function() {
               
                //socket.emit('fetchUsers');
                var a = {
"message":"nothing is happening here o", 
"messageby":"5992e4a72c408200041bcf39"
};
socket.emit('createMsg', a);

});

});

/*
var username = $(this).data('username');
        var message = removeTags($.trim($('#message').val()));
       
                    socket.emit('newmessage', {
                        'username': username,
                        'message': message
                    });
                    $('#message').val('');
                    alert('daserdaved');
                    */